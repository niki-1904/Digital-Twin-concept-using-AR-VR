using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public FixedJoystick joystick;
    public float xRotation;
    public float yRotation;
    public float camSpeed = -0.5f;
    private Vector3 rotateValue;

     void Update()
    {
        xRotation = joystick.input.x;  //Input.GetAxis("Mouse X");
        yRotation = joystick.input.y;  //Input.GetAxis("Mouse Y");
        Debug.Log(xRotation + ":" + yRotation);
        rotateValue = new Vector3(yRotation, xRotation * -1, 0);
        transform.eulerAngles = transform.eulerAngles - rotateValue;
        transform.eulerAngles +=  rotateValue * camSpeed;
    }
}

using System.Collections;
using System;
using UnityEngine.Networking;
using UnityEngine;
using TMPro;


[Serializable]
public class TemperatureData
{
    public MainData main;
    public WeatherData[] weather;
    public WindData wind;
}

[Serializable]
public class MainData
{
    public float temp;
}

[Serializable]
public class WeatherData
{
    public string description;
}

[Serializable]
public class WindData
{
    public float speed;
}

public class ShowTemp : MonoBehaviour
{
    public TextMeshProUGUI weatherText;
    IEnumerator GetTemperature()
    {
        string apiUrl = "https://api.openweathermap.org/data/2.5/weather?lat=21.0000&lon=78.0000&appid=dc651e6ef8aecfd8788101471f7c9b39";

        using (UnityWebRequest www = UnityWebRequest.Get(apiUrl))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                string responseJson = www.downloadHandler.text;

                Debug.Log("API response: " + responseJson);

                // Parse the JSON data
                TemperatureData temperatureData = JsonUtility.FromJson<TemperatureData>(responseJson);

                // Access the temperature value in Celsius
                float temperatureKelvin = temperatureData.main.temp;
                float temperatureCelsius = temperatureKelvin - 273.15f;

                // Access the weather description
                string weatherDescription = temperatureData.weather[0].description;

                // Access the wind speed
                float windSpeed = temperatureData.wind.speed;

                weatherText.text="Temperature in Celsius: " + temperatureCelsius + "\nWeather: " + weatherDescription +"\nWind Speed: " + windSpeed;
            }
            else
            {
                weatherText.text="Failed to fetch temperature data: " + www.error;
            }
        }
    }

    private void Start()
    {
        StartCoroutine(GetTemperature());
    }
}

